TEST
<?php
	print_r(phpinfo());	
?>
