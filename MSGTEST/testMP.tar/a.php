<?

echo "PHP RUN<br>";

$msg =  $_GET['myMsg']; 

echo $msg;
echo  "<br>";

echo "<a href = 'MSGTEST://kj.test.com/";
echo $msg;
echo "'>Run Application</a> </br>";

?>

